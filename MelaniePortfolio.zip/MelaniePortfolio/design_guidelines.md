# Design Guidelines: Melanie Bendix Resume Website

## Design Approach
**Reference-Based: wabi.ai Aesthetic**
This website draws direct inspiration from wabi.ai's bold, narrative-driven design language. The approach prioritizes storytelling over traditional resume formats, using large typography, minimal visual palette, and scroll-driven narrative flow to create an immersive professional profile experience.

## Core Design Principles
- **Narrative First**: Transform resume content into compelling story sections
- **Bold Typography**: Extreme size contrasts create visual impact and hierarchy
- **Minimal Palette**: Monochromatic foundation with strategic accent usage
- **Spacious Breathing**: Generous whitespace between major sections (py-32 to py-48)
- **Scroll-Driven**: Each section reveals progressively, building the professional narrative

## Typography System

**Primary Font Stack**: Inter or Helvetica Neue for clean, modern readability
**Secondary/Display**: Optional serif (Fraunces, Playfair Display) for emphasis moments

**Scale**:
- Hero Name: text-7xl to text-9xl (extremely large, commanding presence)
- Section Headers: text-5xl to text-6xl (bold storytelling moments)
- Narrative Body: text-2xl to text-3xl (larger than traditional, readable paragraphs)
- Supporting Text: text-lg to text-xl (metadata, dates, labels)
- Small Details: text-sm (footnotes, captions)

**Weights**: Regular (400) for body, Bold (700) for emphasis, Light (300) for contrast moments

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 8, 12, 16, 24, 32 (p-8, my-16, gap-4, etc.)

**Container Structure**:
- Full-bleed sections: w-full with inner max-w-6xl px-8
- Narrative content: max-w-4xl for optimal reading
- Compact sections: max-w-3xl

**Section Flow**:
1. Hero (100vh) - Full viewport impact
2. Professional Philosophy (natural height, py-32) - Storytelling narrative
3. Experience Timeline (natural height, py-24) - Chronological journey
4. Skills & Expertise (py-20) - Grid-based showcase
5. Featured Projects/Work (py-24) - Visual portfolio highlights
6. Contact/CTA (py-32) - Minimal, elegant close

## Component Library

**Hero Section**:
- Massive name typography (text-8xl+)
- Subtitle/tagline in contrasting size (text-xl)
- Minimal introductory statement
- Subtle scroll indicator

**Narrative Sections**:
- Large paragraph text (text-2xl to text-3xl)
- Mixed-size typography for emphasis
- Staggered text reveals (mimic wabi.ai's storytelling rhythm)
- Pull quotes or highlighted phrases in larger scale

**Experience Timeline**:
- Vertical timeline with minimal connecting lines
- Company/role headers (text-3xl)
- Date ranges in smaller text (text-sm, uppercase, tracking-wider)
- Achievement bullets in standard paragraph size
- Generous vertical spacing between roles (mb-16 to mb-24)

**Skills Grid**:
- 2-3 column layout (grid-cols-2 lg:grid-cols-3)
- Text-based with strong hierarchy
- Category headers (text-2xl)
- Skill items as clean lists (text-lg)

**Project Cards**:
- Large format cards with ample padding
- Project title (text-3xl)
- Brief description (text-xl)
- Tech stack or role details (text-sm)
- Minimal borders or dividers

**Contact Section**:
- Centered layout
- Simple email/LinkedIn links styled as text (text-xl)
- Optional resume download button
- "Let's connect" or similar minimal CTA

## Images

**Hero Section**: 
- Use a professional portrait/headshot (if available) positioned off-center or as a subtle background element
- Alternative: Abstract geometric pattern or minimal brand mark
- Treatment: High-quality, subtle opacity or grayscale filter to maintain focus on typography

**Project Highlights**:
- 2-3 project screenshots or work samples
- Full-bleed or large format placement
- Maintain monochromatic treatment or subtle color

**Image Specifications**:
- Format: WebP with JPG fallback
- Aspect ratios: 16:9 for projects, 1:1 for portrait
- Lazy loading for performance
- All images should support the narrative, not distract

## Navigation

**Fixed Header**:
- Minimal, transparent background (backdrop-blur-sm)
- Simple text links (Home, Experience, Work, Contact)
- Name/logo on left, nav items right
- Sticky positioning (sticky top-0)

## Interactions

**Scroll Animations** (Very Minimal):
- Fade-in on scroll for section headers
- Subtle parallax effect in hero (if any)
- No aggressive or distracting animations

**Micro-interactions**:
- Link hover: Simple underline transition
- Button hover: Slight opacity or scale change
- All transitions: duration-200 to duration-300

## Accessibility

- Maintain WCAG AA contrast ratios despite minimal palette
- Focus states: Visible outline for keyboard navigation
- Semantic HTML structure (header, main, section, footer)
- Alt text for all images describing professional context
- Skip-to-content link for screen readers

## Responsive Behavior

**Mobile (base to md)**:
- Single column everything
- Reduce hero text size (text-5xl instead of text-9xl)
- Stack timeline vertically with tighter spacing (py-16)
- Increase padding/margins for touch targets

**Tablet (md to lg)**:
- Maintain single column for readability
- Slightly larger typography
- 2-column skill grid

**Desktop (lg+)**:
- Full design system as specified
- Maximum width containers prevent over-expansion
- Optimal line length for narrative text

This design transforms a traditional resume into an immersive, narrative-driven experience that mirrors wabi.ai's bold, minimalist storytelling approach while showcasing Melanie Bendix's professional journey with impact and elegance.