import { motion } from "framer-motion";
import { useState } from "react";

interface HoverRevealProps {
  text: string;
  revealText: string;
  className?: string;
}

export default function HoverReveal({ text, revealText, className = "" }: HoverRevealProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.span
      className={`relative inline-block cursor-pointer ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <motion.span
        className="inline-block"
        animate={{ opacity: isHovered ? 0 : 1, y: isHovered ? -10 : 0 }}
        transition={{ duration: 0.2 }}
      >
        {text}
      </motion.span>
      <motion.span
        className="absolute left-0 top-0 inline-block font-serif italic"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: isHovered ? 1 : 0, y: isHovered ? 0 : 10 }}
        transition={{ duration: 0.2 }}
      >
        {revealText}
      </motion.span>
    </motion.span>
  );
}
