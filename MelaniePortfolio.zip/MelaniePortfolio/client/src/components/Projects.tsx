import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Card } from "@/components/ui/card";
import { AnimatedHeading } from "./AnimatedText";

interface Achievement {
  title: string;
  description: string;
  tags: string[];
}

interface ProjectsProps {
  achievements?: Achievement[];
}

function AchievementCard({ achievement, index }: { achievement: Achievement; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
    >
      <Card
        className="p-8 md:p-12 hover-elevate active-elevate-2 cursor-pointer group overflow-visible"
        data-testid={`card-project-${index}`}
      >
        <motion.div 
          className="space-y-4"
          whileHover={{ scale: 1.01 }}
          transition={{ duration: 0.2 }}
        >
          <motion.h3
            className="text-2xl md:text-3xl font-bold"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 + 0.2 }}
            data-testid={`text-project-title-${index}`}
          >
            {achievement.title}
          </motion.h3>
          <motion.p
            className="text-lg md:text-xl text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 + 0.3 }}
            data-testid={`text-project-description-${index}`}
          >
            {achievement.description}
          </motion.p>
          <div className="flex flex-wrap gap-2 pt-2">
            {achievement.tags.map((tag, tIndex) => (
              <motion.span
                key={tIndex}
                className="text-sm text-muted-foreground px-3 py-1 border rounded-full"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.3, delay: index * 0.1 + 0.4 + tIndex * 0.05 }}
                whileHover={{ scale: 1.05 }}
                data-testid={`tag-project-${index}-${tIndex}`}
              >
                {tag}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </Card>
    </motion.div>
  );
}

export default function Projects({
  achievements = [
    {
      title: "18 Patents Granted",
      description:
        "Recognized as a Master Inventor with 18 patents granted in AI, automation, and hybrid cloud technologies. Over 35 additional applications filed, contributing to IBM's intellectual property leadership.",
      tags: ["AI", "Automation", "Hybrid Cloud", "Innovation"],
    },
    {
      title: "IBM Academy of Technology",
      description:
        "Appointed to IBM's Academy of Technology in 2022—joining the top 600 technical thought leaders globally. Selected for sustained contributions to enterprise technology innovation.",
      tags: ["Technical Leadership", "Thought Leadership", "2022"],
    },
    {
      title: "Global Portfolio Leadership",
      description:
        "Currently leading product strategy across 11 global financial institutions including Citi, Charles Schwab, Fidelity, and American Express. Driving AI and automation solutions at enterprise scale.",
      tags: ["Financial Services", "Enterprise", "Product Strategy"],
    },
    {
      title: "Industry Recognition",
      description:
        "2023 IBM Corporate Technical Recognition Honor Book. 2021 Women in IT Awards Next Generation Leader finalist. 2020 Recognition Experience Honoree (top 2,000 globally). 2017 IBM Cloud Rookie of the Year.",
      tags: ["Awards", "Recognition", "Leadership"],
    },
  ],
}: ProjectsProps) {
  const communityRef = useRef(null);
  const communityInView = useInView(communityRef, { once: true, margin: "-50px" });

  return (
    <section
      id="work"
      className="py-24 md:py-32 px-6 md:px-8 bg-card"
      data-testid="section-projects"
    >
      <div className="max-w-5xl mx-auto">
        <AnimatedHeading
          as="h2"
          className="text-4xl md:text-5xl lg:text-6xl font-bold mb-16 md:mb-24"
        >
          Recognition & Innovation.
        </AnimatedHeading>

        <div className="space-y-8">
          {achievements.map((achievement, index) => (
            <AchievementCard key={index} achievement={achievement} index={index} />
          ))}
        </div>

        <motion.div 
          ref={communityRef}
          className="mt-16 pt-12 border-t"
          initial={{ opacity: 0, y: 20 }}
          animate={communityInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="text-xl font-bold mb-4" data-testid="text-community-title">
            Community
          </h3>
          <p className="text-lg text-muted-foreground" data-testid="text-community">
            Girls Who Code Technical Instructor & IBM Mentor | Women's Bond Club Member
          </p>
        </motion.div>
      </div>
    </section>
  );
}
