export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer
      className="py-8 px-6 md:px-8 border-t"
      data-testid="footer"
    >
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-sm text-muted-foreground" data-testid="text-copyright">
          {currentYear} Melanie Bendix. All rights reserved.
        </p>
        <p className="text-sm text-muted-foreground" data-testid="text-location">
          Based in New York, NY
        </p>
      </div>
    </footer>
  );
}
