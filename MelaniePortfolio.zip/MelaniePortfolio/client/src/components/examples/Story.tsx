import Story from "../Story";

export default function StoryExample() {
  return <Story />;
}
