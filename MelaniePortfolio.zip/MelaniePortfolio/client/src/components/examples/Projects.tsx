import Projects from "../Projects";

export default function ProjectsExample() {
  return <Projects />;
}
