import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { AnimatedHeading, FadeIn } from "./AnimatedText";

interface ExperienceItem {
  company: string;
  role: string;
  period: string;
  description: string;
  achievements?: string[];
}

interface ExperienceProps {
  experiences?: ExperienceItem[];
}

function ExperienceCard({ exp, index }: { exp: ExperienceItem; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      className="grid md:grid-cols-12 gap-6 md:gap-8"
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.6, delay: 0.1 }}
      data-testid={`experience-item-${index}`}
    >
      <div className="md:col-span-4">
        <motion.p
          className="text-sm uppercase tracking-wider text-muted-foreground mb-1"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          data-testid={`text-period-${index}`}
        >
          {exp.period}
        </motion.p>
        <motion.h3
          className="text-2xl md:text-3xl font-bold"
          initial={{ opacity: 0, x: -20 }}
          animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          data-testid={`text-company-${index}`}
        >
          {exp.company}
        </motion.h3>
        <motion.p
          className="text-lg text-muted-foreground"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          data-testid={`text-role-${index}`}
        >
          {exp.role}
        </motion.p>
      </div>

      <div className="md:col-span-8">
        <motion.p
          className="text-xl md:text-2xl mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          data-testid={`text-description-${index}`}
        >
          {exp.description}
        </motion.p>
        {exp.achievements && (
          <ul className="space-y-2">
            {exp.achievements.map((achievement, aIndex) => (
              <motion.li
                key={aIndex}
                className="text-muted-foreground flex items-start gap-3"
                initial={{ opacity: 0, x: 20 }}
                animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                transition={{ duration: 0.4, delay: 0.4 + aIndex * 0.1 }}
                data-testid={`text-achievement-${index}-${aIndex}`}
              >
                <motion.span 
                  className="w-1.5 h-1.5 rounded-full bg-foreground mt-2.5 flex-shrink-0"
                  initial={{ scale: 0 }}
                  animate={isInView ? { scale: 1 } : { scale: 0 }}
                  transition={{ duration: 0.3, delay: 0.5 + aIndex * 0.1 }}
                />
                {achievement}
              </motion.li>
            ))}
          </ul>
        )}
      </div>
    </motion.div>
  );
}

export default function Experience({
  experiences = [
    {
      company: "IBM",
      role: "Manager of Solution Architecture - Financial Services",
      period: "May 2025 — Present",
      description:
        "Leading product strategy and technical roadmap for IBM's full stack technology portfolio across 11 global financial institutions.",
      achievements: [
        "Partner cross-functionally with product management, engineering, and C-suite stakeholders to align AI solutions with client priorities",
        "Drive product positioning for AI implementations across regulatory compliance, operational resilience, and customer experience",
        "Lead team of 12 senior architects delivering technical presentations to executive leadership",
        "Appointed 2025 Master Inventor for sustained innovation leadership in AI and automation",
      ],
    },
    {
      company: "IBM",
      role: "Global Technology Sales Leader - JPMorgan Chase",
      period: "Sept 2023 — May 2025",
      description:
        "Owned end-to-end product strategy and go-to-market execution for IBM's AI, automation, and hybrid cloud portfolio at one of IBM's largest strategic accounts.",
      achievements: [
        "Partnered with JPMC senior technology leaders and IBM product management to shape product roadmap",
        "Developed differentiated product positioning enabling multi-year strategic agreements",
        "Led cross-functional collaboration to take emerging technologies from conception to enterprise deployment",
      ],
    },
    {
      company: "IBM",
      role: "Technical Product & Sales Lead - Hyperscale Partnerships",
      period: "Oct 2021 — Sept 2023",
      description:
        "Led product strategy and technical roadmap for custom storage solutions serving Hyperscale clients, driving 0 to 1 product development.",
      achievements: [
        "Owned voice of customer through surveys, interviews, and beta testing programs",
        "Developed financial models demonstrating 4X TCO savings versus competitive solutions",
        "Launched IBM's first GitHub page for storage automation solutions",
        "Secured $1M+ sales in greenfield markets through data-driven pricing strategy",
      ],
    },
    {
      company: "IBM",
      role: "Technical Sales GTM Strategy & Operations",
      period: "Apr 2021 — Oct 2021",
      description:
        "Partnered with leadership to define product strategy, long-term roadmaps, and KPIs for Americas technical sales organization.",
      achievements: [
        "Led organizational transformation initiatives enhancing workforce productivity by 20%",
        "Developed dashboards tracking product adoption and sales performance",
      ],
    },
    {
      company: "IBM",
      role: "Automation Sales Engineer - Financial Services",
      period: "Aug 2016 — Apr 2021",
      description:
        "Drove product adoption and market success for IBM's automation portfolio across financial services clients.",
      achievements: [
        "Consistently exceeded quotas by 120-882% through deep customer insights",
        "Collaborated with development teams to prioritize feature enhancements based on customer feedback",
        "Selected for Google's Cloud Learning Workshop (87 participants globally)",
      ],
    },
  ],
}: ExperienceProps) {
  const educationRef = useRef(null);
  const educationInView = useInView(educationRef, { once: true, margin: "-50px" });

  return (
    <section
      id="experience"
      className="py-24 md:py-32 px-6 md:px-8 bg-card"
      data-testid="section-experience"
    >
      <div className="max-w-5xl mx-auto">
        <AnimatedHeading
          as="h2"
          className="text-4xl md:text-5xl lg:text-6xl font-bold mb-16 md:mb-24"
        >
          The journey so far.
        </AnimatedHeading>

        <div className="space-y-16 md:space-y-24">
          {experiences.map((exp, index) => (
            <ExperienceCard key={index} exp={exp} index={index} />
          ))}
        </div>

        <motion.div 
          ref={educationRef}
          className="mt-24 pt-16 border-t"
          initial={{ opacity: 0, y: 30 }}
          animate={educationInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
        >
          <h3 className="text-2xl md:text-3xl font-bold mb-4" data-testid="text-education-title">
            Education
          </h3>
          <div className="flex flex-col md:flex-row md:items-baseline gap-2 md:gap-4">
            <span className="text-xl md:text-2xl" data-testid="text-university">Emory University</span>
            <span className="text-muted-foreground" data-testid="text-degree">
              Bachelor's Degree in Computer Science | Applied Mathematics Minor
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
