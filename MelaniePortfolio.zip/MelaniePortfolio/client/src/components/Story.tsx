import { motion, useInView } from "framer-motion";
import { useRef } from "react";

interface StoryProps {
  paragraphs?: string[];
}

function StoryParagraph({ 
  text, 
  index, 
  isHighlight, 
  isQuestion 
}: { 
  text: string; 
  index: number; 
  isHighlight: boolean; 
  isQuestion: boolean;
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.p
      ref={ref}
      className={`leading-relaxed ${
        isHighlight
          ? "text-3xl md:text-4xl lg:text-5xl font-serif italic"
          : isQuestion
          ? "text-2xl md:text-3xl font-medium"
          : "text-xl md:text-2xl text-muted-foreground"
      }`}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.7, delay: 0.1, ease: "easeOut" }}
      data-testid={`text-story-${index}`}
    >
      {isHighlight ? (
        text.split(" ").map((word, i) => (
          <motion.span
            key={i}
            className="inline-block mr-[0.25em]"
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.1 + i * 0.05 }}
          >
            {word}
          </motion.span>
        ))
      ) : (
        text
      )}
    </motion.p>
  );
}

export default function Story({
  paragraphs = [
    "For over 10 years, I've been obsessed with one question:",
    "How do we make AI work for the enterprise?",
    "I started my career as a sales engineer at IBM, helping financial institutions understand automation. But I quickly realized that understanding technology wasn't enough. The real challenge was translating complex AI capabilities into business outcomes.",
    "So I evolved my approach.",
    "I stopped asking \"what can this technology do?\" and started asking \"what should this solve?\" That shift changed everything.",
    "Today, I lead product strategy and technical roadmaps for IBM's AI portfolio across the world's largest financial institutions—Citi, JPMorgan Chase, Fidelity, American Express. I partner with engineering teams to shape products. I translate customer insights into roadmap priorities. I help sales teams close deals.",
    "With 18 patents granted in AI and automation, I don't just talk about innovation—I create it. As a member of IBM's Academy of Technology, I'm among the top 600 technical thought leaders shaping the future of enterprise technology.",
    "That's the work I love. And I'm always looking for the next challenge.",
  ],
}: StoryProps) {
  return (
    <section
      id="story"
      className="py-24 md:py-32 lg:py-40 px-6 md:px-8"
      data-testid="section-story"
    >
      <div className="max-w-4xl mx-auto">
        <div className="space-y-8 md:space-y-12">
          {paragraphs.map((paragraph, index) => {
            const isHighlight = index === 1 || index === 3;
            const isQuestion = paragraph.endsWith("?");

            return (
              <StoryParagraph
                key={index}
                text={paragraph}
                index={index}
                isHighlight={isHighlight}
                isQuestion={isQuestion}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
}
