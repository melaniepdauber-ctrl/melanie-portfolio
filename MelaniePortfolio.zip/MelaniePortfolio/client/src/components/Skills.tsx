import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { AnimatedHeading } from "./AnimatedText";

interface SkillCategory {
  title: string;
  skills: string[];
}

interface SkillsProps {
  categories?: SkillCategory[];
}

function SkillCard({ category, index }: { category: SkillCategory; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      data-testid={`skill-category-${index}`}
    >
      <motion.h3
        className="text-2xl font-bold mb-6"
        initial={{ opacity: 0, x: -20 }}
        animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
        transition={{ duration: 0.4, delay: index * 0.1 + 0.2 }}
        data-testid={`text-category-title-${index}`}
      >
        {category.title}
      </motion.h3>
      <ul className="space-y-3">
        {category.skills.map((skill, sIndex) => (
          <motion.li
            key={sIndex}
            className="text-lg text-muted-foreground hover:text-foreground transition-colors cursor-default"
            initial={{ opacity: 0, x: -10 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -10 }}
            transition={{ duration: 0.3, delay: index * 0.1 + 0.3 + sIndex * 0.05 }}
            whileHover={{ x: 5 }}
            data-testid={`text-skill-${index}-${sIndex}`}
          >
            {skill}
          </motion.li>
        ))}
      </ul>
    </motion.div>
  );
}

export default function Skills({
  categories = [
    {
      title: "Product Management",
      skills: [
        "Product Strategy",
        "Roadmap Development",
        "0-to-1 Product Development",
        "Customer Insights",
        "Market Intelligence",
        "Competitive Analysis",
        "Pricing Strategy",
        "Go-to-Market Strategy",
      ],
    },
    {
      title: "Technical Sales",
      skills: [
        "Solution Architecture",
        "Technical Demonstrations",
        "Proof-of-Concept Development",
        "ROI Analysis",
        "Sales Enablement",
        "Account Strategy",
        "Competitive Positioning",
      ],
    },
    {
      title: "AI & Automation",
      skills: [
        "Applied AI Applications",
        "Conversational AI",
        "Large Language Models",
        "Intelligent Automation",
        "Contact Center AI",
        "Process Automation",
        "Enterprise AI Solutions",
        "Responsible AI Practices",
      ],
    },
    {
      title: "Cross-Functional Leadership",
      skills: [
        "Engineering Collaboration",
        "UX/UI Partnership",
        "Sales & Finance Alignment",
        "Executive Presentations",
        "Stakeholder Management",
        "Product Marketing",
        "Business Operations",
      ],
    },
  ],
}: SkillsProps) {
  return (
    <section
      id="skills"
      className="py-24 md:py-32 px-6 md:px-8"
      data-testid="section-skills"
    >
      <div className="max-w-5xl mx-auto">
        <AnimatedHeading
          as="h2"
          className="text-4xl md:text-5xl lg:text-6xl font-bold mb-16 md:mb-24"
        >
          What I bring.
        </AnimatedHeading>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-8">
          {categories.map((category, index) => (
            <SkillCard key={index} category={category} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
