import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

interface HeroProps {
  name?: string;
  tagline?: string;
  subtitle?: string;
}

export default function Hero({
  name = "Melanie Bendix",
  tagline = "Technology Leader & Master Inventor",
  subtitle = "Driving AI and automation solutions from conception to market success.",
}: HeroProps) {
  const handleScrollDown = () => {
    const storySection = document.getElementById("story");
    if (storySection) {
      storySection.scrollIntoView({ behavior: "smooth" });
    }
  };

  const nameWords = name.split(" ");

  return (
    <section
      id="hero"
      className="min-h-screen flex flex-col justify-center px-6 md:px-8 overflow-hidden"
      data-testid="section-hero"
    >
      <div className="max-w-6xl mx-auto w-full">
        <div className="space-y-6 md:space-y-8">
          <h1
            className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold tracking-tight leading-none"
            data-testid="text-name"
          >
            {nameWords.map((word, i) => (
              <motion.span
                key={i}
                className="block"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: i * 0.2, ease: "easeOut" }}
              >
                {word.split("").map((letter, j) => (
                  <motion.span
                    key={j}
                    className="inline-block"
                    whileHover={{ 
                      scale: 1.1, 
                      color: "hsl(var(--muted-foreground))",
                      transition: { duration: 0.1 }
                    }}
                  >
                    {letter}
                  </motion.span>
                ))}
              </motion.span>
            ))}
          </h1>

          <div className="space-y-4 max-w-2xl">
            <motion.p
              className="text-xl md:text-2xl text-muted-foreground font-light"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              data-testid="text-tagline"
            >
              {tagline}
            </motion.p>
            <motion.p
              className="text-2xl md:text-3xl lg:text-4xl font-serif italic"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              data-testid="text-subtitle"
            >
              {subtitle}
            </motion.p>
          </div>
        </div>
      </div>

      <motion.button
        onClick={handleScrollDown}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 text-muted-foreground hover:text-foreground transition-colors"
        aria-label="Scroll down"
        data-testid="button-scroll-down"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 1.2 }}
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <ChevronDown size={32} />
        </motion.div>
      </motion.button>
    </section>
  );
}
