import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Mail, Linkedin } from "lucide-react";

interface ContactProps {
  email?: string;
  linkedIn?: string;
}

export default function Contact({
  email = "hello@melaniebendix.com",
  linkedIn = "https://linkedin.com/in/melaniebendix",
}: ContactProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      id="contact"
      className="py-32 md:py-40 lg:py-48 px-6 md:px-8"
      data-testid="section-contact"
    >
      <div className="max-w-4xl mx-auto text-center">
        <motion.h2
          className="text-4xl md:text-5xl lg:text-6xl font-bold mb-8"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          data-testid="text-contact-title"
        >
          {"Let's build something extraordinary.".split(" ").map((word, i) => (
            <motion.span
              key={i}
              className="inline-block mr-[0.25em]"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
            >
              {word}
            </motion.span>
          ))}
        </motion.h2>
        
        <motion.p
          className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          data-testid="text-contact-subtitle"
        >
          I'm always open to discussing product strategy, AI innovation, or new opportunities to drive impact at scale.
        </motion.p>

        <motion.div 
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              size="lg"
              className="text-lg px-8"
              onClick={() => window.open(`mailto:${email}`, "_blank")}
              data-testid="button-email"
            >
              <Mail className="mr-2" size={20} />
              Get in touch
            </Button>
          </motion.div>
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              variant="outline"
              size="lg"
              className="text-lg px-8"
              onClick={() => window.open(linkedIn, "_blank")}
              data-testid="button-linkedin"
            >
              <Linkedin className="mr-2" size={20} />
              Connect on LinkedIn
            </Button>
          </motion.div>
        </motion.div>

        <motion.p 
          className="text-muted-foreground"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.4, delay: 0.8 }}
          data-testid="text-location"
        >
          Based in New York, NY
        </motion.p>
      </div>
    </section>
  );
}
