import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  onNavigate?: (section: string) => void;
}

export default function Header({ onNavigate }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (section: string) => {
    if (onNavigate) {
      onNavigate(section);
    }
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-background/80 backdrop-blur-md border-b" : "bg-transparent"
      }`}
      data-testid="header"
    >
      <nav className="max-w-6xl mx-auto px-6 md:px-8 py-4 flex items-center justify-between gap-4">
        <button
          onClick={() => handleNavClick("hero")}
          className="text-lg font-medium tracking-tight hover:opacity-70 transition-opacity"
          data-testid="link-home"
        >
          MB
        </button>

        <div className="hidden md:flex items-center gap-8">
          {["story", "experience", "skills", "work", "contact"].map((item) => (
            <button
              key={item}
              onClick={() => handleNavClick(item)}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors capitalize"
              data-testid={`link-${item}`}
            >
              {item}
            </button>
          ))}
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => handleNavClick("contact")}
          className="hidden md:inline-flex"
          data-testid="button-contact"
        >
          Get in touch
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => handleNavClick("contact")}
          data-testid="button-mobile-menu"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="4" x2="20" y1="12" y2="12" />
            <line x1="4" x2="20" y1="6" y2="6" />
            <line x1="4" x2="20" y1="18" y2="18" />
          </svg>
        </Button>
      </nav>
    </header>
  );
}
